## REGISTRASI AKUN ULT - MAHASISWA

## 1. Tampilan Awal Website

Tekan tombol Login untuk masuk

![](images/page_0_image_3.jpg)

## UNIT LAYANAN TERPADU (ULT) UNIVERSITAS MERCU BUANA

![](images/page_0_image_5.jpg)

## 2. Halaman Login

• Jika sudah memiliki akun wajib mengisi Form Email atau NIM dan Form Kata Sandi

• Terdapat checkbox Ingat Saya untuk menyimpan sesi login (hanya disarankan untuk device pribadi)

Klik tombol Masuk untuk login, jika berhasil akan menuju ke halaman Dashboard

• Jika belum memiliki akun, klik pada text Daftar sekarang untuk melakukan registrasi akun

![](images/page_1_image_0.jpg)

## 3. Daftar Akun Mahasiswa

Pada halaman Daftar Mahasiswa terdapat beberapa form yang harus diisi antara lain NIM, Nama, Email, Kata Sandi, dan Konfirmasi Kata Sandi. Tapi mahasiswa cukup mengisi NIM saja kemudian klik tombol Periksa NIM, jika NIM benar dan terdaftar maka Form Nama dan Email akan secara otomatis terisi. Mahasiswa tinggal mengisi form No. Telepon, Kata Sandi dan Konfirmasi Kata Sandi. Checklist jika data sudah sesuai kemudian klik tombol Daftar.

![](images/page_1_image_3.jpg)

## 1. Profile Mahasiswa

Tampilan awal

Fitur ini berisi data pribadi dan data perkuliahan mahasiswa. Data diambil langsung dari database sehingga mahasiswa tidak dapat melakukan penambahan, perubahan, maupun penghapusan data.

![](images/page_2_image_4.jpg)

## 2. Pengajuan Surat Pengantar

## • Tampilan awal

Fitur ini dapat digunakan oleh mahasiswa untuk mengajukan surat pengantar dengan keperluan Riset, Penelitian, atau Magang. Halaman utama berisi list data pengajuan yang telah mahasiswa buat. Data yang ditambahkan awalnya masih berupa draft sehingga mahasiswa masih dapat melakukan perubahan, penambahan, dan penghapusan data pengajuan sebelum dikirimkan. Jika sudah yakin datanya sesuai mahasiswa dapat mengirimkan pengajuan dengan menekan tombol “Kirim”. Mahasiswa dapat melakukan print out surat pengantar jika statusnya sudah disetujui.

<table><tr><td colspan="8">List Data Pengajuan Surat Pengantar</td></tr><tr><td>No</td><td>Periode</td><td>Alasan Permintaan Surat</td><td>Topik Penelitian</td><td>Jenis Penelitian</td><td>Status</td><td>Tanggal Permintaan</td><td>Aksi</td></tr><tr><td>1</td><td>Ganjil</td><td>Est molestiae solut</td><td>Consequatur id eiu</td><td>Riset / Penelitian</td><td>Draft</td><td>12/1/2025</td><td>Edit Delete Kirim
Draft Print</td></tr><tr><td>2</td><td>Ganjil</td><td>Inventore voluptasc</td><td>Et voluptatem imped</td><td>Magang</td><td>Draft</td><td>12/1/2025</td><td>Edit Delete Kirim
Draft Print</td></tr><tr><td colspan="7">Show 10 per page</td><td>1-2 of 2 ← 1 →</td></tr></table>

## Tambah data

Berikut ini adalah tampilan form yang harus diisi oleh mahasiswa untuk melakukan pengajuan surat pengantar. Semua form wajib diisi dan wajib melampirkan dokumen --- dengan format PDF. Jika semua data sudah diisi, klik tombol tambah untuk menyimpan draft pengajuan. Atau klik tombol “Tutup” untuk membatalkan pengajuan.

![](images/page_3_image_3.jpg)

![](images/page_4_image_0.jpg)

No file chosen

Choose file

![](images/page_4_image_3.jpg)

Choose niie

![](images/page_4_image_6.jpg)

Choose file

No file chosen

Dashboard Pengajuan Surat Pengantar Keterangan Lulus Pendaftaran Bimbingan Proposal Pendaftaran Sidang Proposal Informasi Pendaftaran Bimbingan Akhir Pendaftaran Sidang Akhir Informasi Sidang Akhir

Pengajuan Surat Pengantar Pengajuan Surat Keterangan Lulus Pendaftaran Bimbingan Proposal Pendaftaran Sidang Proposal Informasi Sidang Proposal Pendaftaran Bimbingan Akhir Pendaftaran Sidang Akhir Informasi Sidang Akhir

| No | Periode | Alasan Permintaan Surat | Topik Penelitian | Jenis Penelitian | Status | Tanggal Permintaan | Akoi |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Tahun 2026 | Persyaratan Magang | Topik Penelitian | Magang | Draft | 30/07/2025 | ESB Delee XorinDraft Prind |

Pengajuan Surat Pengantar

| No | Periode | Alasan Permintaan Surat | Topik Penellitian | Jenis Penellitian | Status | Tanggal Permintaan | Aksi |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Tahun 2026 | Persyaratan Magang | Topik Penellitian | Magang | Terkirim | 30/07/2025 | EHR Delete Giroan Draft Print |

## 3. Bimbingan

Tampilan awal

Fitur ini dapat digunakan oleh mahasiswa untuk melakukan pendaftaran Bimbingan Proposal / Tugas Akhir. Halaman utama berisi list data pengajuan yang telah mahasiswa buat.

![](images/page_6_image_0.jpg)

![](images/page_6_image_1.jpg)

Gambar dibawah ini adalah tampilan pengajuan yang sedang menunggu di-assign dosen pembimbingnya oleh Kaprodi. Sebagai catatan mahasiswa hanya dapat melakukan satu kali pengajuan bimbingan dalam satu periode dan data yang sudah dikirimkan tidak dapat diubah maupun dihapus. Mahasiswa dapat melakukan melakukan pergantian judul jika mahasiswa dinyatakan gagal dalam tugas sebelumnya dan harus mengulang bimbingan.

②Dashboard Pengajuan Surat Pengantar Pengajuan Surat Keterangan Lulus Pendaftaran Bimbingan Proposal Logbook Mahasiswa Bimbingan Proposal Pendaftaran Sidang Proposal Hasil Sidang Proposal Informasi Sidang Proposal Pendaftaran Bimbingan Akhir Logbook Mahasiswa Bimbingan Akhir Pendaftaran

Bimbingan Tugas Proposal

| No | Tahun Akademik | Nama Mahasiswa | Nim | Prodi | Judul Tugas Proposal | Dosen Pembimbing | Status Bimbingan | Aksi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Tahun 2025 | DINDA FATIMAH KAUTSARINA | 41521010114 | Teknik Informatika | PREDICTIVE MODELS FOR SCOPE-1 CO2 EMISSIONS FROM INDONESIAN CEMENT MANUFACTURERS USING MACHINE LEARNING |  | BELUM BIMBINGAN | - |

Tampilan daftar pengajuan bimbingan yang sudah di assign, akan muncul nama dosen pembimbing yang sebelumnya kosong dan muncul tombol “Detail”, status bimbingan juga berubah menjadi “BIMBINGAN SEDANG BERJALAN”. Jika tombol “Detail” di klik akan berpindah ke tampilan Logbook.

Dashboard Profile Mahasiswa Pengajuan Surat Pengantar Pengajuan Surat Keterangan Lulus Logbook Mahasiswa Bimbingan Proposal Pendaftaran Sidang Proposal Hasil Sidang Proposal Informasi Sidang Proposal Pendaftaran Bimbingan Akhir Logbook Mahasiswa Bimbingan Akhir Pendaftaran Cisnnn Alhiz

![](images/page_7_image_6.jpg)

Pengajuan Surat Pengantar

Pengajuan Surat Keterangan Lulus

Pendaftaran Bimbingan Proposal

Pendaftaran Sidang Proposal

Hasil Sidang Proposal

Informasi Sidang Proposal

Pendaftaran Bimbingan Akhir

Logbook Mahasiswa Bimbingan Akhit

Pendaftaran

Tampilan Logbook Bimbingan Sidang yang berisi informasi mahasiswa, dosen pembimbing, judul skripsi, dan daftar bimbingan yang sedang/telah dilakukan. Mahasiswa dapat melakukan bimbingan dengan cara menekan tombol “Tambah”.

Profile Mahasiswa

Pengajuan Surat Pengantar

Pengajuan Surat Keterangan Lulus

Pendaftaran Bimbingan Proposal

Logbook Mahasiswa Bimbingan Proposal

Pendaftaran Sidang Proposal

Hasil Sidang Proposal

Bimbingan Tugas Proposal

<table><tr><td colspan="9">List Data Pengajuan Tugas Proposal</td></tr><tr><td>No</td><td>Tahun Akademik</td><td>Nama Mahasiswa</td><td>Nim</td><td>Prodi</td><td>Judul Tugas Proposal</td><td>Dosen Pembimbing</td><td>Status Bimbingan</td><td>Aksi</td></tr><tr><td>1</td><td>Tahun 2025</td><td>DINDA FATIMAH KAUTSARINA</td><td>41521010114</td><td>Teknik Informatika</td><td>PREDICTIVE MODELS FOR SCOPE-1 CO2 EMISSIONS FROM INDONESIAN CEMENT MANUFACTURERS USING MACHINE LEARNING</td><td>Zendi Ikilima S.Kom, S.T, M.Sc</td><td>BELUM BIMBINGAN</td><td>Detail</td></tr><tr><td colspan="7">Show 5 per page</td><td>1-1 of 1</td><td>1 →</td></tr></table>

Informasi Sidang Proposal

Pendaftaran Bimbingan Akhir

Logbook Mahasiswa Bimbingan Akhir

Pendaftaran

![](images/page_8_image_24.jpg)

Tampilan Tambah Data Bimbingan, mahasiswa dapat mengisi tanggal bimbingan, keterangan bimbingan, dan mahasiswa dapat melakukan upload dokumen proposal / tugas akhir yang akan diperiksa oleh dosen pembimbing. File bimbingan harus memiliki format pdf atau doc/docx, dan ukuran filenya tidak lebih dari 5MB.

![](images/page_9_image_1.jpg)

Setelah disimpan akan muncul data bimbingan baru dengan status dospem “BELUM DI CHECK”, mahasiswa tinggal menunggu dosen pembimbing memeriksa file bimbingan dan memberikan feedback. Mahasiswa harus melakukan minimal 5 (lima) kali bimbingan proposal dan 8 (delapan) kali bimbingan akhir sebagai salah satu syarat untuk dapat melakukan pendaftaran sidang.

![](images/page_9_image_3.jpg)

![](images/page_10_image_0.jpg)

Jika dosen pembimbing sudah mengkonfirmasi bahwa bimbingan telah selesai maka status bimbingan akan berubah menjadi “BIMBINGAN SELESAI” dan mahasiswa dapat melakukan pendaftaran sidang.

![](images/page_10_image_2.jpg)

## 4. Pendaftaran Sidang

Tampilan informasi pendaftaran sidang. Tombol tambah akan muncul jika mahasiswa sudah memenuhi persyaratan untuk pendaftaran sidang, jika salah satu persyaratan belum terpenuhi maka tombol tambah tidak akan muncul dan mahasiswa belum dapat melakukan pendaftaran sidang.

![](images/page_11_image_1.jpg)

Tampilan form pendaftaran sidang. Semua form di dalamnya sudah terisi secara otomatis berdasarkan data pada database. Mahasiswa hanya perlu upload file proposal / tugas akhir kemudian klik tombol simpan. Setelah itu mahasiswa menunggu hingga bagian prodi

![](images/page_11_image_3.jpg)

Tampilan setelah tu prodi menyetujui pendaftaran sidang dari mahasiswa. Kolom status pendaftaran akan berubah dari sebelumnya “TERKIRIM” menjadi “DISETUJUI”. Dan terdapat tombol detail untuk melihat detail pendaftaran sidang.

![](images/page_12_image_1.jpg)

Tampilan detail pendaftaran sidang yang berisi data mahasiswa, judul skripsi, dan status pengajuan pendaftaran sidang mahasiswa.

![](images/page_12_image_3.jpg)

## 5. Informasi Sidang

Tampilan Informasi Sidang muncul setelah mahasiswa melakukan pendaftaran sidang dan pihak prodi sudah menyetujuinya. Terdapat informasi ruangan sidang yang telah ditentukan oleh TU prodi. Mahasiswa dapat menekan tombol Detail untuk melihat catatan sidang dari dosen penguji dan mengirimkan revisi.

![](images/page_13_image_1.jpg)

Detail Informasi Sidang yang berisi hasil sidang mahasiswa dan catatan dari dosen penguji sidang, mahasiswa dapat mengirimkan revisi sesuai dengan catatan yang diberikan oleh penguji sidang.

![](images/page_14_image_0.jpg)

## 6. Pendaftaran Wisuda

Tampilan halaman Pendaftaran Wisuda dimana mahasiswa dapat melakukan pendaftaran wisuda dengan menekan tombol Tambah jika semua persyaratan sudah terpenuhi.

![](images/page_15_image_0.jpg)

Tampilan form pendaftaran wisuda, semua form wajib diisi oleh mahasiswa danjuga melakukan upload semua dokumen yang dibutuhkan sesuai dengan judul filenya. Jika semua data sudah terisi tekan tombol Simpan.

![](images/page_15_image_2.jpg)

![](images/page_16_image_0.jpg)

![](images/page_16_image_1.jpg)

![](images/page_16_image_2.jpg)

Tampilan halaman Pendaftaran Wisuda setelah mahasiswa mengisi formulir, mahasiswa masih bisa mengubah data pendaftaran jika diperlukan. Jika sudah yakin dengan data yang diberikan bisa menekan tombol Kirim dan menunggu pendaftaran wisuda disetujui.

![](images/page_16_image_4.jpg)

Dashboard Profile Mahasiswa Pengajuan Surat Pengantar Pengajuan Surat Keterangan Lulus Pendaftaran Bimbingan Proposal Pendaftaran Sidang Proposal Informasi Sidang Proposal Pendaftaran Bimbingan Akhir Pendaftaran Sidang Akhir Informasi Sidang Akhir Pendaftaran Wisuda

![](images/page_16_image_6.jpg)

Dashboard

Profile Mahasiswa Pengajuan Surat Pengantar Pendaftaran Bimbingan Proposal Pendaftaran Sidang Proposal Informasi Sidang Proposal Pendaftaran Bimbingan Akhir Pendaftaran Sidang Akhir Informasi Sidang Akhir Pendaftaran Wisuda

Pendaftaran Wisuda

![](images/page_16_image_10.jpg)

1. Mahasiswa wajib berstatus lulus.

Pendaftaran Wisuda

![](images/page_16_image_13.jpg)

| Nama lengkap | Prodi | Periode wisuda | Ukuran toga | Status Pendaftaran | Status Verifikasi | No registrasi | No wisuda | Action |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ARRIVAL DWI SENTOSA | Teknik informatika | TA 2025-2026 | L | DRAFT | BELUM DIVERIFIKASI | 25-2Periode wisuda 20264150002 |  | KaitDelaripKtrim |

Pendaftaran Wisuda

Syarat Pendaftaran Wisuda

![](images/page_16_image_17.jpg)

![](images/page_16_image_18.jpg)

![](images/page_16_image_19.jpg)

![](images/page_16_image_20.jpg)

Pendaftaran Wisuda

<table><tr><td>Nama lengkap</td><td>Prodi</td><td>Periode wisuda</td><td>Ukuran toga</td><td>Status Pendaftaran</td><td>Status Verifikasi</td><td>No registrasi</td><td>No wisuda</td><td>Action</td></tr><tr><td>ARRIVAL DWI SENTOSA</td><td>Teknik Informatika</td><td>TA 2025-2026</td><td>L</td><td>TERKIRIM</td><td>BELUM DIVERIFIKASI</td><td>25-2Periode wisuda 20264150002</td><td></td><td>Detail</td></tr><tr><td colspan="7">Show 5 per page</td><td>1-1 of 1</td><td>← 1 →</td></tr></table>

![](images/page_17_image_0.jpg)

Setelah pendaftaran disetujui statusnya akan berubah menjadi SUDAH DIVERIFIKASI dan mahasiswa akan mendapatkan nomor wisuda.

<table><tr><td>Nama lengkap</td><td>Prodi</td><td>Periode wisuda</td><td>Ukuran toga</td><td>Status Pendaftaran</td><td>Status Verifikasi</td><td>No registrasi</td><td>No wisuda</td><td>Action</td></tr><tr><td>ARRIVAL DWI SENTOSA</td><td>Teknik Informatika</td><td>TA 2025-2026</td><td>L</td><td>TERKIRIM</td><td>SUDAH DIVERIFIKASI</td><td>25-2Periode wisuda 20264150002</td><td>002</td><td>Detail</td></tr><tr><td colspan="7">Show 5 per page</td><td>1-1 of 1</td><td>← 1 →</td></tr></table>